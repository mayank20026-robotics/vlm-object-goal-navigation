#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
import math
import os
import sys
import json
import numpy as np
import PIL.Image
from google import genai
import cv2
import time  # <--- ADD THIS
from geometry_msgs.msg import Twist

class VLMHybridCommander(Node):
    def __init__(self, target_object):    # <--- Add target_object here
        super().__init__('vlm_hybrid_commander')
        self.goal_pub = self.create_publisher(PoseStamped, '/goal_pose', 10)
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10) # Your spin publisher
        self.timer = self.create_timer(1.0, self.execute_vlm_command)
        self.has_fired = False

        self.target_object = target_object # <--- Save it to the class

        # --- CAMERA INTRINSICS ---
        self.fx = 911.904
        self.fy = 911.677
        self.cx = 642.827
        self.cy = 376.307
        self.robot_width_m = 0.5

    def get_quaternion_from_euler(self, roll, pitch, yaw):
        qx = math.sin(roll/2) * math.cos(pitch/2) * math.cos(yaw/2) - math.cos(roll/2) * math.sin(pitch/2) * math.sin(yaw/2)
        qy = math.cos(roll/2) * math.sin(pitch/2) * math.cos(yaw/2) + math.sin(roll/2) * math.cos(pitch/2) * math.sin(yaw/2)
        qz = math.cos(roll/2) * math.cos(pitch/2) * math.sin(yaw/2) - math.sin(roll/2) * math.sin(pitch/2) * math.cos(yaw/2)
        qw = math.cos(roll/2) * math.cos(pitch/2) * math.cos(yaw/2) + math.sin(roll/2) * math.sin(pitch/2) * math.sin(yaw/2)
        return [qx, qy, qz, qw]

    # Draw visual visual grounding
    def draw_visual_grounding_hud(self, cv_image):
        """Draws a physical scale overlay on the image using Pinhole Math"""
        # We will draw reference lines at 1.0m, 1.5m, and 2.0m distances
        reference_depths = [1.0, 1.5, 2.0]
        color = (0, 255, 0) # Green HUD

        for Z in reference_depths:
            # Calculate how many pixels wide the robot is at this depth
            pixel_width = int((self.robot_width_m * self.fx) / Z)
            
            # We assume the floor is roughly in the lower third of the image.
            # We map 1.0m to v=650, 1.5m to v=550, 2.0m to v=450 (approximate perspective)
            v_pixel = int(750 - (Z * 150)) 
            
            u_left = int(self.cx - (pixel_width / 2))
            u_right = int(self.cx + (pixel_width / 2))

            # Draw the horizontal depth line and width brackets
            cv2.line(cv_image, (u_left, v_pixel), (u_right, v_pixel), color, 2)
            cv2.line(cv_image, (u_left, v_pixel - 10), (u_left, v_pixel + 10), color, 2)
            cv2.line(cv_image, (u_right, v_pixel - 10), (u_right, v_pixel + 10), color, 2)
            cv2.putText(cv_image, f"{Z}m Distance | {self.robot_width_m}m Width", 
                        (u_left, v_pixel - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            
        return cv_image
    
    # Execute VLM for width and open spaces
    def execute_vlm_command(self):
        if self.has_fired:
            return
        self.has_fired = True
        
        base_path = os.path.expanduser("~/ros2_ws/src/oak_object_detection/oak_object_detection/")
        
        self.get_logger().info("Loading Camera Frame and Depth Map...")
        try:
            cv_image = cv2.imread(os.path.join(base_path, "vlm_test_frame.jpg"))
            # Load the raw millimeter data!
            depth_map = np.load(os.path.join(base_path, "depth_data.npy")) 
        except Exception as e:
            self.get_logger().error(f"Failed to load data: {e}")
            sys.exit()

        # Draw the HUD and save the grounded image for VLM
        hud_image = self.draw_visual_grounding_hud(cv_image)
        hud_path = os.path.join(base_path,'vlm_grounded_frame.jpg')
        cv2.imwrite(hud_path,hud_image)

        API_KEY = "AIzaSyA9hDpFHzea24vwYSBpXjDFIbnvKffv34U"  # PASTE NEW KEY HERE
        client = genai.Client(api_key=API_KEY)
        img_for_vlm = PIL.Image.open(hud_path)
        
        # --- THE NEW SENSOR FUSION PROMPT ---
        prompt = f"""
        You are the executive perception node for an autonomous robot.
        The user command is: "Go to {self.target_object}."
        Look at the provided camera frame. I have drawn a green HUD on the floor representing 0.5m physical widths.
        
        If you see the target: calculate the safest floor path toward it. Ensure the path is wide enough for the 0.5m HUD brackets.
        If you DO NOT see the target, or if the entire front view is blocked by obstacles: you must command the robot to search.
        
        Respond ONLY with a raw JSON object using one of these two formats:
        Success: {{"action": "drive", "u": 640, "v": 550}}
        Failure: {{"action": "search"}}
        """
        
        self.get_logger().info("Querying Cognitive Cloud (Gemini)...")
        # --- ROBUST RETRY LOGIC ---
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                response = client.models.generate_content(model='gemini-2.5-flash', contents=[prompt, img_for_vlm])
                clean_text = response.text.strip().replace("```json", "").replace("```", "")
                coord = json.loads(clean_text)

                # --- ACTIVE PERCEPTION FORK ---
                if coord.get("action") == "search":
                    self.get_logger().warn("Target not in view. Initiating 45-degree search spin...")
                    
                    # Create a rotation command
                    spin_cmd = Twist()
                    spin_cmd.angular.z = 0.5  # Spin left at 0.5 rad/s
                    
                    # Publish the spin
                    self.cmd_pub.publish(spin_cmd)
                    
                    # Let it spin for 1.5 seconds (roughly 45 degrees depending on your chassis)
                    time.sleep(1.5) 
                    
                    # Stop the motors
                    spin_cmd.angular.z = 0.0
                    self.cmd_pub.publish(spin_cmd)
                    
                    # Reset the loop so the timer fires again and takes a NEW picture
                    self.has_fired = False 
                    return
                
                # Ensure pixels are integers
                pixel_u = int(coord['u'])
                pixel_v = int(coord['v'])
                
                # If we made it here, it was successful! Break out of the retry loop.
                break 
                
            except Exception as e:
                self.get_logger().warn(f"Cloud API Hiccup (Attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    sleep_time = 2 ** attempt  # Exponential backoff: sleeps 1s, then 2s
                    self.get_logger().info(f"Retrying in {sleep_time} seconds...")
                    time.sleep(sleep_time)
                else:
                    self.get_logger().error("Cognitive Cloud unreachable. Halting robot for safety.")
                    rclpy.shutdown()
                    sys.exit()
                    
        self.get_logger().info(f"VLM Targeted Pixel: [{pixel_u}, {pixel_v}]")
           

        # --- THE TRUE SENSOR FUSION MATH ---
        # 1. Look up the hardware Z-distance (in millimeters)
        # We take a 5x5 average around the pixel in case the exact pixel has a depth hole (0 value)
        roi = depth_map[max(0, pixel_v-2):min(720, pixel_v+3), max(0, pixel_u-2):min(1280, pixel_u+3)]
        valid_depths = roi[roi > 0]
        
        if len(valid_depths) == 0:
            self.get_logger().error("Hardware Depth at that pixel is 0 (Blind spot). Aborting.")
            rclpy.shutdown()
            return
            
        Z_mm = np.median(valid_depths)
        Z_meters = Z_mm / 1000.0

        # 2. Matrix Clearance Check
        # Calculate how many pixels wide the robot is at the target depth
        chassis_pixel_width = int((self.robot_width_m * self.fx) / Z_meters)
        u_left_bound = max(0, pixel_u - (chassis_pixel_width // 2))
        u_right_bound = min(1280, pixel_u + (chassis_pixel_width // 2))

        # Slice the depth map to look at the "Safety Corridor"
        # We look at a 10-pixel high band across the entire calculated width of the robot
        corridor_slice = depth_map[max(0, pixel_v-5):min(720, pixel_v+5), u_left_bound:u_right_bound]
        valid_corridor_depths = corridor_slice[corridor_slice > 0] / 1000.0 # convert to meters

        # Check if anything in the corridor is dangerously close
        # If an object is more than 0.3 meters closer than the target floor, it's an obstacle!
        collision_points = valid_corridor_depths[valid_corridor_depths < (Z_meters - 0.3)]
        
        if len(collision_points) > int(chassis_pixel_width * 0.1): # If more than 10% of the corridor is blocked
            self.get_logger().error(f"HARDWARE VETO: Detected obstacle in safety corridor. Gap is too narrow for {self.robot_width_m}m chassis. Aborting.")
            rclpy.shutdown()
            return

        self.get_logger().info("Depth-Gate Cleared: Physical clearance validated via hardware matrix.")

        # --- PHASE 3: COMMAND GENERATION ---
        cam_x = ((pixel_u - self.cx) * Z_meters) / self.fx
        target_x = Z_meters      # Distance forward
        target_y = -cam_x        # Distance left/right

        self.get_logger().info(f"Target Waypoint: Forward (X): {target_x:.2f}m, Lateral (Y): {target_y:.2f}m")

        goal = PoseStamped()
        goal.header.frame_id = 'base_link'  
        goal.header.stamp = self.get_clock().now().to_msg()
        goal.pose.position.x = float(target_x)
        goal.pose.position.y = float(target_y)
        goal.pose.position.z = 0.0
        
        yaw = math.atan2(target_y, target_x)
        q = self.get_quaternion_from_euler(0.0, 0.0, yaw)
        goal.pose.orientation.x = q[0]
        goal.pose.orientation.y = q[1]
        goal.pose.orientation.z = q[2]
        goal.pose.orientation.w = q[3]

        self.goal_pub.publish(goal)
        self.get_logger().info(">>> HYBRID GOAL SENT TO NAV2! <<<")
        rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)

    # --- GET HUMAN INPUT BEFORE STARTING ---
    print("\n" + "="*50)
    print("🧠 SUMO COGNITIVE NAVIGATION SYSTEM")
    print("="*50)
    target = input("Enter your semantic target (e.g., 'the red chair', 'the door'): ")
    print(f"Target locked: {target}. Booting ROS 2 node...\n")

    node = VLMHybridCommander(target_object=target)
    rclpy.spin(node)

if __name__ == '__main__':
    main()